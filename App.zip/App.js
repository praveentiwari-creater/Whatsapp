import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';
import TEST1 from './DEMO/TEST1';
import TEST2 from './DEMO/TEST2';
import TEST3 from './DEMO/TEST3';
import TEST4 from './DEMO/TEST4';
import TEST5 from './DEMO/TEST5';
import TEST6 from './DEMO/TEST6';
import Header_Component from './DEMO/Header_component';

const Stack = createStackNavigator();
const Tab = createMaterialTopTabNavigator();
const Drawer = createDrawerNavigator();

export default class APP extends React.Component {
  render() {
    return (
      <NavigationContainer>
        <Stack.Navigator >
          <Stack.Screen name="WhatsApp" component={TAB_NAVIGATION}
            options={{
              headerTitle: props => <Header_Component/>,
              headerStyle: {
                backgroundColor: 'powdergrey',
                height:170,               
               elevation:0,
                           },
              headerTintColor: 'powdergrey',
              headerTitleStyle: {
                fontWeight: 'bold',
                             },
                }} />
<Stack.Screen name="DRAWER_NAVIGATION" component={DRAWER_NAVIGATION}/>

        </Stack.Navigator>
      </NavigationContainer>
    )
  }
}
function TAB_NAVIGATION() {
  return (
    <Tab.Navigator
      tabBarOptions={{
        labelStyle: { fontSize: 20, fontWeight: 'bold' },
        tabStyle: { width: 115 },
        style: { backgroundColor: 'powdergrey' },
        scrollEnabled: true,
        activeTintColor: 'black',
        inactiveTintColor: 'grey',
        pressColor: 'pink',
      }}>
      <Tab.Screen name="CAMERA" component={TEST1} />
      <Tab.Screen name="CHATS" component={TEST2} />
      <Tab.Screen name="STATUS" component={TEST3} />
      <Tab.Screen name="CALLS" component={TEST4} />
      <Tab.Screen name="CONT" component={TEST5} />
      <Tab.Screen name="SETTING" component={TEST6} />
    </Tab.Navigator>
  );
}

